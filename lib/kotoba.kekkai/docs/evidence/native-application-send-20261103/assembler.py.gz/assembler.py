from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

R=Path('/Users/junkawasaki/github/wt/codex/awai122-remote-management-20261102')
S=Path(__file__).parent
O=R/'lib/kotoba.kekkai/docs/evidence/native-application-send-20261103'
STATE=['sender-state-normal-v7','sender-state-cancel-unknown-v1',*[f'sender-state-{f}-fault-v1' for f in ['window','unknown','wipe','channel']]]
LINK=['sender-responder-normal-v3','sender-initiator-normal-v1','sender-initiator-unknown-v1','sender-responder-payload-fault-v1']
EXTRA=['sender-legacy-pending-v1','sender-profile-refusals-v2']
FAILED=['sender-responder-probe-v1','sender-responder-normal-v2',*[f'sender-state-probe-v{n}' for n in [1,2,3,4,5]],'sender-profile-refusals-v1']

def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):b=p.read_bytes();return dict(bytes=len(b),sha256=sha(b))
def frozen(target,raw):
    target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    return dict(file=target.name,original=dict(bytes=len(raw),sha256=sha(raw)),compressed=pin(target))

rows={}
for name in STATE+LINK+EXTRA:
    p=S/name/'receipt.json';d=json.loads(p.read_text())
    want=('DETECTED_NATIVE_SEND_STATE_FAULT' if '-fault-' in name else 'PASS_NATIVE_APPLICATION_SEND_STATE') if name in STATE else (
        'DETECTED_NORMALLY_COMPLETED_RECEIVE_FAULT' if '-fault-' in name else 'PASS_FULL_NATIVE_APPLICATION_SEND') if name in LINK else (
        'PASS_NATIVE_APPLICATION_PENDING' if 'pending' in name else 'PASS_EXPLICIT_PROFILE_REFUSALS')
    assert d['state']==want,(name,d['state'],want)
    if name in STATE:assert d['normalCompletion'] and d['phases']==64 and d['nativeChecks']==2208
    if name in LINK:
        v=d['receiveResult']['observed'];assert v['terminal']==2 and v['cases'] in [2081,2084] and v['released']==v['cases'] and v['rxErrors']==0
        assert d['receiveResult']['nativeRequest']['plaintextBytes']==1048576 and d['receiveResult']['nativeRequest']['fragments']==1498
        assert d['receiveResult']['fullResponseBytes']==1048576
    if name in STATE+LINK+EXTRA[:1]:
        stage=S/name/'source'
        for virtual,h in d['sourceGraph'].items():assert pin(stage/virtual.lstrip('/'))['sha256']==h,(name,virtual)
        assert pin(stage/'kernel.elf')==pin(stage/'kernel-repeat.elf')
        assert pin(stage/'boot.efi')==pin(stage/'boot-repeat.efi')
        assert d['layout']['rx'][5]<=2093056 and d['layout']['rw'][5]==2359296
    if name in STATE+LINK:
        p=S/name/'observer-source.py';assert pin(p)==d['observer'],(name,'observer source')
    rows[name]=d

assert rows['sender-legacy-pending-v1']['nativeChecks']==1133
for label in LINK[:2]+[LINK[2]]:
    assert rows[label]['receiveResult']['violations']==[] and rows[label]['receiveResult']['observed']['nativeErrors']==0
assert rows[LINK[3]]['receiveResult']['observed']['nativeErrors']==0
assert rows[LINK[3]]['receiveResult']['violations']==['new-epoch-part0-completes: fullOutgoingRequestBytes']

O.mkdir(parents=True,exist_ok=False)
proof=dict(schema='kekkai.native-application-send.v1',state='PASS_NATIVE_FRAGMENTED_SEND_AND_LIFETIME',issue='JUN-757',
    compiler=rows[LINK[0]]['compiler'],compilerProfile='pool-v5-transmit',
    nativeMacBackend=False,installedApp=False,physicalDeployment=False,serviceExecution=False,trustedConsent=False,
    nativeSSH=False,hostileCPL3Executed=False,releaseQualified=False,globalCompilerAdoption=False,
    productionSources={},observerVersions={},runs={},failedProbesPreserved=[],snapshots={},
    retainedLimits=dict(requestBytes=1048576,receiveBytes=8388608,transmitBytes=1048576,parts=2048,assemblies=128,bufferedBytes=4194304,pendingRequests=256,schedulerDomains=4,codeBytes=2093056),
    metadataOwnerBytes=24576,diagnosticOwnedScratchPages=[4,5,6,7,8,9],
    remaining=['configured service/direction/exact port/normalized endpoint/socket and canonical fresh trusted consent',
        'production host allocation/coexistence with complete desktop; controller multi-peer scheduling and ambiguous-operation reconciliation',
        'native Mac backend, actual Mac/6600H app install/live peer/revoke/reconnect/native SSH',
        'production keys/config, entropy/time, durable floors, hostile-CPL3 execution, final-counter exhaustion, concurrent rekey/roaming/operations',
        'all mandatory OS daily-use, distributed OS and L1 production gates'])
for name in ['application_send_region','application_pending_region','session_region','application_frame_region','frame_region','application_message_region','application_response_region','application_reassembly_region','application_receive_region']:
    rel=f'lib/kotoba.kekkai/kotoba/kekkai/{name}.kotoba';proof['productionSources'][rel]=pin(R/rel)
snapshot_index={}
archive=O/'native-memory.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for name,d in rows.items():
        rr=dict(state=d['state'],receipt=frozen(O/(name+'.json.gz'),(S/name/'receipt.json').read_bytes()))
        if name in STATE+LINK:
            rr['layout']=d['layout'];rr['sourceGraph']=d['sourceGraph'];rr['compiler']=d['compiler']
            rr['observer']=frozen(O/(name+'-observer.py.gz'),(S/name/'observer-source.py').read_bytes())
            proof['observerVersions'][name]=rr['observer']
        if name in STATE:
            rr.update(nativeChecks=d['nativeChecks'],nativeErrors=d['nativeErrors'],independentMismatches=len(d['observationFailures']),normalCompletion=d['normalCompletion'],refusalComparisons=24)
            files=[(S/name/'qemu'/f,meta) for item in d['checkpoints'] for f,meta in item['owners'].items()]
            for rel in ['public_reference.py']:
                rr[rel]=frozen(O/(name+'-'+rel+'.gz'),(S/name/rel).read_bytes())
        elif name in LINK:
            v=d['receiveResult'];rr.update(nativeChecksErrors=v['observed']['nativeErrors'],independentMismatches=len(v['violations']),protocolPackets=v['observed']['cases'],nativeRequest=v['nativeRequest'],fullResponseSHA256=v['fullResponseSHA256'],refusalComparisons=53)
            files=[(S/name/f"shape-{item['phase']:03}-{region}.gz",meta) for item in d['shapeCheckpoints'] for region,meta in item['owners'].items()]
            rr['frozenPeer']=frozen(O/(name+'-peer.py.gz'),(S/name/'public-fixtures/scripts/native_application_send_peer.py').read_bytes())
            for rel in ['native-client-request.bin','native-client-fragments.bin.gz','native-client-request-plaintext.bin.gz']:
                p=S/name/rel
                if p.exists():rr[rel]=frozen(O/(name+'-'+rel+'.gz'),p.read_bytes())
        elif 'pending' in name:
            rr.update(nativeChecks=d['nativeChecks'],nativeErrors=d['nativeErrors'],normalCompletion=d['normalCompletion'],independentMismatches=len(d['observationFailures']))
            files=[(S/name/'qemu'/f,meta) for item in d['checkpoints'] for f,meta in item['owners'].items()]
        else:files=[]
        rr['snapshotMembers']=len(files)
        for p,meta in files:
            raw=gzip.decompress(p.read_bytes());assert dict(bytes=len(raw),sha256=sha(raw))==meta,(name,p)
            key=name+'/'+p.name;assert key not in snapshot_index;snapshot_index[key]=meta
            data=p.read_bytes();entry=tarfile.TarInfo(key);entry.size=len(data);entry.mtime=0;entry.mode=0o600;t.addfile(entry,io.BytesIO(data))
        proof['runs'][name]=rr

# Every actual snapshot member is reopened, decompressed and hash checked.
seen=set()
with tarfile.open(archive) as t:
    for entry in t:
        assert entry.name in snapshot_index and entry.name not in seen
        raw=gzip.decompress(t.extractfile(entry).read());assert dict(bytes=len(raw),sha256=sha(raw))==snapshot_index[entry.name]
        seen.add(entry.name)
assert len(seen)==5796,(len(seen),len(snapshot_index))
(O/'memory-index.json').write_text(json.dumps(snapshot_index,indent=2)+'\n')
proof['snapshots']=dict(archive=pin(archive),index=pin(O/'memory-index.json'),membersReopened=len(seen),allIndependentHashesMatched=True)
for name in FAILED:
    p=S/name/'receipt.json';item=dict(label=name,qualified=False)
    item['reason']={
        'sender-responder-probe-v1':'Five-domain fixture exceeds the four non-evicting domain slots; old observer waits until setup timeout. Not a normally completed fault.',
        'sender-responder-normal-v2':'Reserved scratch retains loader sentinel; host failed to zero metadata before initialize. No native request emitted.',
        'sender-state-probe-v1':'Pinned baseline already has public response templates; old empty-template staging assertion refuses.',
        'sender-state-probe-v2':'E7106: bound parser exports lacked actual typed fixture callers.',
        'sender-state-probe-v3':'E7106 persists with generic helper removal; actual bound export callers still missing.',
        'sender-state-probe-v4':'Fixture failed to zero reserved scratch before initialize; native and independent checks fail.',
        'sender-state-probe-v5':'Fixture failed to restore frame output capacity after raw handshake reused its header; commands correctly refuse.',
        'sender-profile-refusals-v1':'Old producer correctly returns usage exit2; initial harness expected exit1.'}[name]
    if p.exists():item['receipt']=frozen(O/(name+'-failed.json.gz'),p.read_bytes())
    for suffix in ['kernel.elf.stderr','kernel.elf.stdout']:
        p=S/name/suffix
        if p.exists():item[suffix]=frozen(O/(name+'-'+suffix+'.gz'),p.read_bytes())
    proof['failedProbesPreserved'].append(item)
proof['nativeLayouts']={n:rows[n]['layout'] for n in STATE+LINK}
proof['assembler']=frozen(O/'assembler.py.gz',Path(__file__).read_bytes())
proof['dependencyCI']=frozen(O/'amu9010-ci-readback.json.gz',(S/'sender-amu-ci-readback.json').read_bytes())
(O/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n')
print('ASSEMBLED',pin(O/'receipt.json'),len(seen),flush=True)
